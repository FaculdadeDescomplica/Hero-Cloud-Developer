import { Component } from '@angular/core';
import { FieldType } from '@ngx-formly/core';

@Component({
  selector: 'formly-field-file',
  template: `
    <input type="file" [formControl]="formControl" (change)="handleUpload($event)" [formlyAttributes]="field">
  `,
})
export class FormlyFieldFile extends FieldType {
  private _formControl: any;
  public override get formControl(): any {
        return this._formControl;
  }

  handleUpload(event: any) {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      this.model.image = reader?.result?.toString();
    };
  }
}
